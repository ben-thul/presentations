backup log [AdventureWorks2014]
to disk = 'c:\temp\AdventureWorks2014_LOG.trn'
with init, retaindays = 1, checksum
