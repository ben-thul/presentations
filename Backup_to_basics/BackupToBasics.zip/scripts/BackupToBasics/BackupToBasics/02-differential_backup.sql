backup database [AdventureWorks2014]
to disk = 'c:\temp\AdventureWorks2014_DIFF.bak'
with init, retaindays = 1, checksum
, differential
