backup database [AdventureWorks2014]
to disk = 'c:\temp\AdventureWorks2014_FULL.bak'
with copy_only
    , init
    , retaindays = 1