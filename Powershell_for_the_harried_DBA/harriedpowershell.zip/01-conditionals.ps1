﻿if ($true) {
   "This is executed"
}

if ($false) {
   "This is not executed"
}
elseif (1+1 -eq 3) {
   "This is also not executed"
}
else {
   "Finally executed!"
}
